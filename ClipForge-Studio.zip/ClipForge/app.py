"""Loopback-only companion server for the ClipForge desktop browser UI."""
import argparse
import json
import mimetypes
import os
import re
import secrets
import shutil
import threading
import traceback
import webbrowser
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlsplit
from uuid import uuid4

import engine

ROOT = engine.ROOT
DATA = Path(os.getenv('CLIPFORGE_DATA') or (ROOT / 'workspace')).resolve()
TOKEN = secrets.token_hex(24)
JOBS = {}
LOCK = threading.Lock()
WORKER = ThreadPoolExecutor(max_workers=1)
ID = r'[a-f0-9]{32}'


def submit(task):
    key = uuid4().hex

    def update(**values):
        with LOCK:
            JOBS[key].update(values)

    def work():
        def report(msg):
            update(message=msg)
        try:
            result = task(report)
            update(state='done', result=result)
        except Exception as exc:
            traceback.print_exc()
            update(state='error', message=str(exc))

    with LOCK:
        JOBS[key] = dict(state='running', message='Queued for local processing')
    WORKER.submit(work)
    return key


def project(key):
    if not re.fullmatch(ID, str(key or '')):
        raise ValueError('Invalid project.')
    folder = DATA / 'projects' / key
    info = folder / 'source.json'
    if not info.is_file():
        raise ValueError('Import a source video first.')
    meta = json.loads(info.read_text(encoding='utf-8'))
    return folder, folder / meta['file'], meta


def save_json(path, data):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
    temp.replace(path)


def option(data, name, allowed, default):
    value = data.get(name, default)
    if value not in allowed:
        raise ValueError(f'Invalid {name} choice.')
    return value


def number(data, key, low, high):
    try:
        val = float(data[key])
    except (TypeError, KeyError, ValueError) as exc:
        raise ValueError(f'Enter a number for {key}.') from exc
    if not low <= val <= high:
        raise ValueError(f'{key.capitalize()} must be between {low:g} and {high:g}.')
    return val


def text_field(data, key, size):
    return re.sub(r'\s+', ' ', str(data.get(key, ''))).strip()[:size]


def analyze_options(data):
    language = text_field(data, 'language', 4)
    if language and not re.fullmatch('[a-z]{2,3}', language):
        raise ValueError('Enter a language code like en, hi, or gu for Whisper.')
    return dict(language=language, model=option(data, 'model', ('tiny', 'base', 'small', 'medium'), 'base'),
                device=option(data, 'device', ('auto', 'gpu', 'cpu'), 'auto'),
                count=int(number(data, 'count', 1, 12)), length=number(data, 'length', 12, 80),
                speech=data.get('speech') is True)


def export_options(data, meta):
    start = number(data, 'start', 0, meta['duration'])
    end = number(data, 'end', 0, meta['duration'])
    if end - start < .9:
        raise ValueError('The end must be at least 0.9 seconds after the start.')
    return dict(start=start, end=end, frame=number(data, 'frame', start, end),
                style=option(data, 'style', engine.STYLES, 'reaction'),
                theme=option(data, 'theme', ('poster', 'impact', 'editorial'), 'poster'),
                framing=option(data, 'framing', ('crop', 'blur'), 'crop'),
                device=option(data, 'device', ('auto', 'gpu', 'cpu'), 'auto'),
                hook=text_field(data, 'hook', 88), cover=text_field(data, 'cover', 88),
                emoji=data.get('emoji') is True, caption_y=number(data, 'caption_y', 42, 77),
                pan=number(data, 'pan', 0, 100))


def analysis_job(folder, path, opts, report):
    result = engine.analyze(path, opts, report)
    for clip in result['clips']:
        thumb = folder / f'thumb-{clip["id"]}.jpg'
        try:
            engine.ff(['-ss', str(clip['frame']), *engine.ff_input(path), '-map', f"0:{result['meta']['video']}",
                       '-vf', 'scale=288:-2', '-frames:v', '1', '-q:v', '4', str(thumb)])
        except RuntimeError:
            pass
    save_json(folder / 'analysis.json', result)
    return {**result, 'segments': [], 'groups': engine.caption_groups(result['segments'], 0, result['meta']['duration'])}


def clip_job(path, folder, meta, opts, groups, cover_only, report):
    key = uuid4().hex
    if cover_only:
        report('Composing the cover preview')
        dest = folder / 'covers'
        dest.mkdir(exist_ok=True)
        engine.make_cover(path, meta, opts, dest / f'{key}.jpg')
        return {'cover': f'/cover/{folder.name}/{key}.jpg'}
    dest = DATA / 'exports' / key
    dest.mkdir(parents=True)
    try:
        encoder = engine.export(path, meta, opts, groups, dest, report)
    except Exception:
        shutil.rmtree(dest, ignore_errors=True)
        raise
    for item in dest.iterdir():
        if item.name not in {'clip.mp4', 'cover.jpg', 'captions.srt', 'caption.ass'}:
            item.unlink()
    return dict(encoder=encoder, video=f'/export/{key}/clip.mp4', cover=f'/export/{key}/cover.jpg',
                srt=f'/export/{key}/captions.srt' if groups else '', ass=f'/export/{key}/caption.ass',
                saved=str(dest))


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        if args and str(args[1] if len(args) > 1 else '').startswith('5'):
            super().log_message(fmt, *args)

    def allowed(self):
        return self.headers.get('Host') == f'127.0.0.1:{self.server.server_port}'

    def respond(self, data, code=200):
        raw = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(raw)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        try:
            self.wfile.write(raw)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def file(self, path):
        if not path.is_file():
            self.respond({'error': 'File missing.'}, 404)
            return
        size = path.stat().st_size
        start, end = 0, size - 1
        req = self.headers.get('Range')
        if req:
            match = re.fullmatch(r'bytes=(\d*)-(\d*)', req)
            if not match or not any(match.groups()):
                self.send_error(416)
                return
            a, b = match.groups()
            if a:
                start = int(a)
                end = min(end, int(b)) if b else end
            else:
                start = max(0, size - int(b))
            if start > end or start >= size:
                self.send_response(416)
                self.send_header('Content-Range', f'bytes */{size}')
                self.end_headers()
                return
        self.send_response(206 if req else 200)
        self.send_header('Content-Type', mimetypes.guess_type(path)[0] or 'application/octet-stream')
        self.send_header('Content-Length', str(end - start + 1))
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Cross-Origin-Resource-Policy', 'same-origin')
        self.send_header('Content-Security-Policy', "default-src 'self'; media-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; frame-ancestors 'none'; base-uri 'none'")
        self.send_header('Accept-Ranges', 'bytes')
        if req:
            self.send_header('Content-Range', f'bytes {start}-{end}/{size}')
        self.end_headers()
        if self.command == 'HEAD':
            return
        with path.open('rb') as f:
            f.seek(start)
            remaining = end - start + 1
            while remaining:
                block = f.read(min(remaining, 1024 * 1024))
                if not block:
                    break
                self.wfile.write(block)
                remaining -= len(block)

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        if not self.allowed():
            self.send_error(403)
            return
        path = urlsplit(self.path).path
        try:
            if path == '/':
                self.file(ROOT / 'web' / 'index.html')
            elif path in ('/ui.js', '/style.css'):
                self.file(ROOT / 'web' / path[1:])
            elif path == '/api/config':
                self.respond(dict(token=TOKEN, styles=engine.STYLES))
            elif match := re.fullmatch(f'/api/job/({ID})', path):
                with LOCK:
                    status = JOBS.get(match[1], {}).copy()
                self.respond(status or {'error': 'Job not found.'}, 200 if status else 404)
            elif match := re.fullmatch(f'/source/({ID})', path):
                self.file(project(match[1])[1])
            elif match := re.fullmatch(rf'/thumb/({ID})/(\d{{1,2}})', path):
                self.file(project(match[1])[0] / f'thumb-{match[2]}.jpg')
            elif match := re.fullmatch(rf'/cover/({ID})/({ID})\.jpg', path):
                self.file(project(match[1])[0] / 'covers' / f'{match[2]}.jpg')
            elif match := re.fullmatch(rf'/export/({ID})/(clip\.mp4|cover\.jpg|captions\.srt|caption\.ass)', path):
                self.file(DATA / 'exports' / match[1] / match[2])
            elif match := re.fullmatch(r'/assets/(Caption-Bold\.ttf|laugh\.png|shock\.png|fire\.png|skull\.png|idea\.png|eyes\.png)', path):
                self.file(engine.ASSETS / match[1])
            else:
                self.respond({'error': 'Page not found.'}, 404)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except ValueError as exc:
            self.respond({'error': str(exc)}, 404)

    def upload(self):
        length = int(self.headers.get('Content-Length', 0))
        if not 0 < length <= 100 * 1024 ** 3:
            raise ValueError('Choose a nonempty local video under 100 GB.')
        name = unquote(self.headers.get('X-File-Name', 'video')).replace('\\', '/').rsplit('/', 1)[-1]
        ext = Path(name).suffix.lower()
        file = 'source' + (ext if re.fullmatch(r'\.[a-z0-9]{1,8}', ext) else '.mp4')
        key = uuid4().hex
        folder = DATA / 'projects' / key
        folder.mkdir(parents=True)
        source = folder / file
        try:
            with source.open('wb') as f:
                while length:
                    data = self.rfile.read(min(length, 1024 * 1024))
                    if not data:
                        raise ValueError('The local file transfer ended early.')
                    f.write(data)
                    length -= len(data)
            info = dict(engine.probe(source), name=name, file=file)
            save_json(folder / 'source.json', info)
            return dict(id=key, meta=info)
        except Exception:
            shutil.rmtree(folder, ignore_errors=True)
            raise

    def do_POST(self):
        origin = self.headers.get('Origin')
        if not self.allowed() or self.headers.get('X-ClipForge-Token') != TOKEN or (
            origin and origin != f'http://127.0.0.1:{self.server.server_port}'
        ):
            self.send_error(403)
            return
        path = urlsplit(self.path).path
        try:
            if path == '/api/import':
                self.respond(self.upload())
                return
            if path not in ('/api/analyze', '/api/cover', '/api/export'):
                self.respond({'error': 'Unknown action.'}, 404)
                return
            size = int(self.headers.get('Content-Length', 0))
            if not 0 < size < 24_000:
                raise ValueError('Invalid request size.')
            data = json.loads(self.rfile.read(size))
            if not isinstance(data, dict):
                raise ValueError('Invalid request.')
            folder, source, meta = project(data.get('project'))
            if path == '/api/analyze':
                opts = analyze_options(data)
                job = submit(lambda report: analysis_job(folder, source, opts, report))
            else:
                opts = export_options(data, meta)
                if path == '/api/cover':
                    job = submit(lambda report: clip_job(source, folder, meta, opts, [], True, report))
                else:
                    analysis = folder / 'analysis.json'
                    segments = json.loads(analysis.read_text(encoding='utf-8'))['segments'] if analysis.is_file() else []
                    groups = [g for g in engine.caption_groups(segments, 0, meta['duration'])
                              if g[0][0] < opts['end'] and g[-1][1] > opts['start']]
                    job = submit(lambda report: clip_job(source, folder, meta, opts, groups, False, report))
            self.respond({'job': job}, 202)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except (ValueError, RuntimeError, OSError) as exc:
            self.respond({'error': str(exc)}, 400)


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--port', type=int, default=8765)
    cli.add_argument('--no-browser', action='store_true')
    args = cli.parse_args()
    DATA.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault('HF_HUB_DISABLE_TELEMETRY', '1')
    with ThreadingHTTPServer(('127.0.0.1', args.port), Handler) as server:
        address = f'http://127.0.0.1:{server.server_port}'
        print(f'ClipForge is running at {address}\nKeep this window open. Press Ctrl+C to close.', flush=True)
        if not args.no_browser:
            threading.Timer(.45, webbrowser.open, args=(address,)).start()
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == '__main__':
    main()
