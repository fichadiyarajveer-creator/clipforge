"""Local media analysis and export for ClipForge."""
import json
import math
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageOps

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / 'assets'
FFMPEG = shutil.which('ffmpeg') or str(ROOT / 'bin' / 'ffmpeg.exe')
FFPROBE = shutil.which('ffprobe') or str(ROOT / 'bin' / 'ffprobe.exe')
FLAGS = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
WIDTH, HEIGHT = 1080, 1920
STYLES = {
    'reaction': dict(name='Reaction Pop', accent='#98ff38', size=82, stroke=9, upper=True, effect='pop', box=False, sample='That was wild'),
    'karaoke': dict(name='Golden Karaoke', accent='#ffd842', size=80, stroke=8, upper=True, effect='plain', box=False, sample='Watch this part'),
    'bubble': dict(name='Purple Bubble', accent='#e8d5ff', size=72, stroke=0, upper=False, effect='pop', box=True, sample='Wait for it'),
    'impact': dict(name='Red Impact', accent='#ff4a66', size=106, stroke=10, upper=True, effect='pop', box=False, sample='No way'),
    'clean': dict(name='Clean Creator', accent='#71e9ff', size=67, stroke=5, upper=False, effect='plain', box=False, sample='Here is the trick'),
    'minimal': dict(name='White Minimal', accent='#ffffff', size=58, stroke=4, upper=False, effect='plain', box=False, sample='Let me explain'),
}
EMOJI_RULES = {
    'laugh': r'\b(laugh\w*|hilarious|funny|lmao|joke)\b',
    'shock': r"\b(no way|oh my god|what the|impossible|shocked|unbelievable|crazy)\b",
    'fire': r'\b(fire|insane|incredible|amazing|perfect|wild|strong)\b',
    'skull': r"\b(dead|rip|i'm done|i am done|destroyed|cooked)\b",
    'idea': r'\b(secret|tip|trick|learned|realized|mistake)\b',
    'eyes': r'\b(look at|look here|watch this|did you see|wait for it)\b',
}
HOOK_PATTERNS = (
    (r'^(wait|look|watch|stop|hold on|guess|listen|imagine|what|why|how)\b', 0.75, 'Direct opening'),
    (r'\b(no way|never|secret|mistake|wrong|biggest|only|first time|plot twist)\b', 0.68, 'Surprise or stakes'),
    (r"\b(i tried|i thought|i found|it turns out|here is|here's|the reason)\b", 0.60, 'Setup with a payoff'),
    (r'\b(\d+|percent|dollars?)\b', 0.30, 'Concrete detail'),
)
CONTEXT_START = re.compile(r'^(and then|but then|so anyway|like i said|as i said|because of that|yeah|um|uh)\b', re.I)


def run(args, cwd=None):
    try:
        result = subprocess.run(args, cwd=cwd, capture_output=True, creationflags=FLAGS)
    except FileNotFoundError as exc:
        raise RuntimeError('FFmpeg or FFprobe was not found. Install FFmpeg and reopen ClipForge.') from exc
    if result.returncode:
        msg = result.stderr.decode('utf-8', errors='replace').strip().splitlines()
        raise RuntimeError(' | '.join(msg[-4:]) or 'The media command failed.')
    return result.stdout


def ff(args, cwd=None):
    return run([FFMPEG, '-hide_banner', '-loglevel', 'error', '-y', *args], cwd)


def probe(path):
    data = json.loads(run([FFPROBE, '-v', 'error', '-protocol_whitelist', 'file,pipe', '-show_format', '-show_streams', '-of', 'json', str(path)]))
    video = next((s for s in data['streams'] if s['codec_type'] == 'video' and not s.get('disposition', {}).get('attached_pic')), None)
    if video is None:
        raise ValueError('Choose a file that contains a video track.')
    duration = float(data['format'].get('duration') or video.get('duration') or 0)
    if not math.isfinite(duration) or duration < 1:
        raise ValueError('Choose a video at least one second long with a valid duration.')
    rotation = next((int(x['rotation']) for x in video.get('side_data_list', []) if 'rotation' in x), 0)
    width, height = video['width'], video['height']
    if rotation % 180:
        width, height = height, width
    return dict(duration=round(duration, 3), width=width, height=height, video=video['index'],
                audio=any(s['codec_type'] == 'audio' for s in data['streams']))


def ff_input(path):
    return ['-threads', '2', '-protocol_whitelist', 'file,pipe', '-i', str(path)]


def normalized(values):
    if not len(values):
        return np.zeros(1)
    low, high = np.quantile(values, [.25, .97])
    return np.clip((values - low) / max(high - low, .025), 0, 1)


def signals(path, meta):
    raw = ff([*ff_input(path), '-map', f"0:{meta['video']}", '-an', '-sn',
              '-vf', 'fps=2,scale=40:24:flags=area,format=gray',
              '-pix_fmt', 'gray', '-threads', '1', '-f', 'rawvideo', 'pipe:1'])
    pixels = np.frombuffer(raw, dtype=np.uint8).reshape((-1, 960)).astype(np.float32) / 255
    changes = np.abs(np.diff(pixels, axis=0, prepend=pixels[:1])).mean(axis=1) if len(pixels) else np.zeros(1)
    if not meta['audio']:
        return np.zeros(1), normalized(changes), changes
    raw = ff([*ff_input(path), '-map', '0:a:0', '-vn', '-ac', '1', '-ar', '8000', '-f', 's16le', 'pipe:1'])
    pcm = np.frombuffer(raw, dtype='<i2')
    frames = pcm[:len(pcm) // 4000 * 4000].reshape((-1, 4000))
    rms = np.sqrt(np.mean(np.square(frames.astype(np.float32) / 32768), axis=1)) if len(frames) else np.zeros(1)
    return normalized(rms), normalized(changes), changes


def transcribe(path, options, report):
    import ctranslate2
    from faster_whisper import WhisperModel

    choice = options['device']
    modes = ['cpu']
    if choice != 'cpu' and ctranslate2.get_cuda_device_count() > 0:
        modes.insert(0, 'cuda')
    note = 'NVIDIA CUDA unavailable. Used the CPU.' if choice == 'gpu' and modes == ['cpu'] else ''
    for device in modes:
        report(f'Loading {options["model"]} Whisper model on {"NVIDIA GPU" if device == "cuda" else "CPU"}. First use may download the model.')
        try:
            model = WhisperModel(os.getenv('CLIPFORGE_MODEL_PATH') or options['model'], device=device,
                                 compute_type='int8_float16' if device == 'cuda' else 'int8',
                                 cpu_threads=min(os.cpu_count() or 4, 8))
            segments, info = model.transcribe(str(path), language=options['language'] or None, beam_size=3,
                                              vad_filter=True, word_timestamps=True, condition_on_previous_text=False)
            result = []
            last = -30
            for segment in segments:
                words = [[round(w.start, 3), round(w.end, 3), w.word.strip()]
                         for w in segment.words or [] if w.word.strip() and w.end > w.start]
                if words:
                    result.append(dict(start=words[0][0], end=words[-1][1], text=segment.text.strip(), words=words))
                if segment.end - last >= 10:
                    last = segment.end
                    report(f'Transcribing speech on {"GPU" if device == "cuda" else "CPU"} · {int(segment.end)}s of source')
            return result, info.language, 'NVIDIA CUDA' if device == 'cuda' else 'CPU', note
        except (RuntimeError, ValueError) as exc:
            if device == 'cpu':
                raise
            note = f'CUDA could not run the model. Used the CPU. {str(exc).splitlines()[0][:160]}'
    raise RuntimeError('Speech recognition could not start.')


def sentence_units(segments):
    units = []
    pending = []
    for segment in segments:
        for word in segment['words']:
            if pending and (word[0] - pending[-1][1] > .8 or word[0] - pending[0][0] > 11):
                units.append(pending)
                pending = []
            pending.append(word)
            if re.search(r'[.!?।。！？][”"\']?$', word[2]):
                units.append(pending)
                pending = []
    if pending:
        units.append(pending)
    return units


def heat(series, start, end):
    part = series[max(0, int(start * 2)):max(1, math.ceil(end * 2))]
    return float(np.quantile(part, .75)) if len(part) else 0.0


def excerpt(text, words=8):
    text = re.sub(r'\s+', ' ', text).strip()
    chunks = text.split()
    if len(chunks) > words:
        text = ' '.join(chunks[:words]).rstrip(',;:-') + '…'
    return text[:84]


def rank_clips(meta, segments, audio, motion, raw_cuts, count, target):
    duration = meta['duration']
    units = sentence_units(segments)
    ends = np.array([unit[-1][1] for unit in units])
    starts = [(max(0, unit[0][0] - .12), unit) for unit in units]
    # Peaks and scene boundaries supply candidates for action-heavy or wordless footage.
    peak = .56 * motion.copy()
    common = min(len(peak), len(audio))
    peak[:common] += .44 * audio[:common]
    if len(peak) >= 3:
        peaks = np.flatnonzero((peak[1:-1] >= peak[:-2]) & (peak[1:-1] > peak[2:]) & (peak[1:-1] > .35)) + 1
        used = []
        for i in sorted(peaks, key=lambda j: peak[j], reverse=True):
            t = max(0, i / 2 - 1.6)
            if any(abs(t - last) < 4 for last in used):
                continue
            nearby = next((u for u in units if abs(u[0][0] - t) < 1.2), None)
            if nearby is None:
                starts.append((t, None))
            used.append(t)
            if len(used) >= max(40, count * 7):
                break
    if duration <= target + 1 or not units:
        starts.append((0.0, None))
    if not units:
        starts.extend((float(t), None) for t in np.arange(target, duration, target))
    candidates = []
    for start, unit in starts:
        if duration - start < min(8, duration):
            continue
        goal = min(duration, start + target)
        end = goal
        if unit and len(ends):
            possible = ends[(ends >= start + target * .65) & (ends <= min(duration, start + target * 1.2))]
            if len(possible):
                end = min(duration, float(possible[np.argmin(abs(possible - goal))]) + .25)
        spoken = ' '.join(w[2] for w in unit) if unit else ''
        opening = spoken.lower()
        features = []
        hook = 0.0
        for pattern, weight, label in HOOK_PATTERNS:
            if re.search(pattern, opening[:100]):
                hook += weight
                features.append(label)
        if '?' in opening[:100]:
            hook += .5
            features.append('Opening question')
        if CONTEXT_START.search(opening):
            hook -= .56
        early = heat(audio, start, min(end, start + 3))
        visual = heat(motion, start, min(end, start + 4))
        payoff = .54 * heat(motion, max(start, end - 6), end) + .46 * heat(audio, max(start, end - 6), end)
        if visual > .55:
            features.append('Early visual activity')
        if early > .55:
            features.append('Early audio peak')
        if payoff > .60:
            features.append('End-of-clip activity')
        completeness = .11 if unit and abs(end - goal) > .05 else 0
        length_penalty = .26 * max(0, 1 - (end - start) / min(duration, target))
        score = .20 + .28 * min(1.65, hook) + .14 * early + .16 * visual + .14 * payoff + completeness - length_penalty
        if unit:
            score += .10
        title = excerpt(spoken)
        if not title and (early > .6 or visual > .6):
            title = 'Watch what happens next'
        reason = features[:3] or (['Starts on a spoken phrase'] if unit else ['Video and audio activity'])
        candidates.append(dict(start=round(float(start), 3), end=round(float(end), 3),
                               hook=title, reason=reason, score=max(1, min(99, round(score * 100)))))
    chosen = []
    for clip in sorted(candidates, key=lambda item: item['score'], reverse=True):
        span = clip['end'] - clip['start']
        if all(max(0, min(other['end'], clip['end']) - max(other['start'], clip['start']))
               / min(span, other['end'] - other['start']) <= .28 for other in chosen):
            chosen.append(clip)
            if len(chosen) == count:
                break
    for i, clip in enumerate(chosen, 1):
        start, end = clip['start'], clip['end']
        lower = start + min(.4, (end - start) * .15)
        upper = min(end - .25, start + (end - start) * .82)
        frame_times = np.arange(lower, max(lower + .1, upper), .5)
        frame = max(frame_times, key=lambda t: .55 * heat(audio, t, t + .5)
                    + .45 * heat(motion, t + .5, t + 1)
                    - .65 * heat(raw_cuts, t, t + .5))
        clip.update(id=i, frame=round(float(frame), 3))
    return chosen


def caption_groups(segments, start, end):
    groups = []
    group = []
    for segment in segments:
        for a, b, text in segment['words']:
            if a >= end or b <= start:
                continue
            if group and (len(group) >= 4 or sum(len(w[2]) + 1 for w in group) + len(text) > 24
                          or a - group[-1][1] > .45 or b - group[0][0] > 2.5):
                groups.append(group)
                group = []
            group.append([max(start, a), min(end, b), text])
            if re.search(r'[.!?।。！？]+$', text):
                groups.append(group)
                group = []
    if group:
        groups.append(group)
    return groups


def analyze(path, options, report):
    meta = probe(path)
    report('Measuring motion, scene changes, and audio peaks')
    audio, motion, cuts = signals(path, meta)
    segments, language, device, note = [], '', 'Visual and audio', ''
    if options['speech'] and meta['audio']:
        try:
            segments, language, device, note = transcribe(path, options, report)
            if not segments:
                note = (note + ' No clear speech was detected.').strip()
        except Exception as exc:
            note = f'Speech recognition was unavailable. Clips were ranked by activity. {str(exc).splitlines()[0][:220]}'
    elif options['speech']:
        note = 'This video has no audio track.'
    report('Ranking moments and preserving room for the payoff')
    clips = rank_clips(meta, segments, audio, motion, cuts, options['count'], options['length'])
    return dict(meta=meta, segments=segments, clips=clips, language=language, device=device, note=note)


def emoji_for(words):
    sentence = ' '.join(w[2] for w in words).lower()
    return next((name for name, pattern in EMOJI_RULES.items() if re.search(pattern, sentence)), '')


def color_ass(hex_color):
    return '&H00' + ''.join(reversed(re.findall('..', hex_color[1:]))) + '&'


def ass_text(text):
    # Fullwidth lookalikes keep user text from creating ASS override tags or newlines.
    return str(text).replace('\\', '＼').replace('{', '｛').replace('}', '｝').replace('\n', ' ').replace('\r', ' ')


def timestamp(seconds, srt=False):
    precision = 1000 if srt else 100
    ticks = max(0, round(seconds * precision))
    hours, rem = divmod(ticks, 3600 * precision)
    minutes, rem = divmod(rem, 60 * precision)
    whole, fraction = divmod(rem, precision)
    return f'{hours:02d}:{minutes:02d}:{whole:02d},{fraction:03d}' if srt else f'{hours}:{minutes:02d}:{whole:02d}.{fraction:02d}'


def wrap(text, font, limit):
    lines = []
    current = ''
    for word in text.split():
        if font.getlength(word) > limit:
            if current:
                lines.append(current)
                current = ''
            partial = ''
            for char in word:
                if partial and font.getlength(partial + char) > limit:
                    lines.append(partial)
                    partial = ''
                partial += char
            current = partial
        elif current and font.getlength(current + ' ' + word) > limit:
            lines.append(current)
            current = word
        else:
            current = (current + ' ' + word).strip()
    if current:
        lines.append(current)
    return lines


def captions(groups, opts, directory):
    st = STYLES[opts['style']]
    y = round(HEIGHT * opts['caption_y'] / 100)
    font_name = opts['font']
    lines = [
        '[Script Info]', 'ScriptType: v4.00+', f'PlayResX: {WIDTH}', f'PlayResY: {HEIGHT}', 'WrapStyle: 0',
        'ScaledBorderAndShadow: yes', '', '[V4+ Styles]',
        'Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding',
        f'Style: Main,{font_name},{st["size"]},&H00FFFFFF,&H00FFFFFF,&H0013171E,&H5013171E,-1,0,0,0,100,100,0,0,{3 if st["box"] else 1},{15 if st["box"] else st["stroke"]},3,5,90,90,0,1',
        f'Style: Hook,{font_name},78,&H00FFFFFF,&H00FFFFFF,&H00151417,&H30151417,-1,0,0,0,100,100,0,0,1,9,4,5,80,80,0,1',
        '', '[Events]', 'Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text',
    ]

    def event(a, b, style, label):
        if round(b * 100) > round(a * 100):
            lines.append(f'Dialogue: 0,{timestamp(a)},{timestamp(b)},{style},,0,0,0,,{label}')

    hook = opts['hook'].strip()
    if hook:
        words = wrap(hook, ImageFont.truetype(str(ASSETS / 'Caption-Bold.ttf'), 78), 880)
        event(0, min(2.65, opts['end'] - opts['start']), 'Hook',
              r'{\pos(540,430)\fad(70,200)}' + r'\N'.join(ass_text(t) for t in words))

    srt = []
    emojis = {}
    offset = opts['start']
    limit = opts['end']
    for group in groups:
        clean = [(max(0, a - offset), min(limit, b) - offset, t) for a, b, t in group if a < limit and b > offset]
        if not clean:
            continue
        start, end = clean[0][0], clean[-1][1]
        srt += [str(len(srt) // 4 + 1), f'{timestamp(start, True)} --> {timestamp(end, True)}',
                ' '.join(w[2] for w in clean), '']
        name = emoji_for(clean) if opts['emoji'] else ''
        if name:
            emojis.setdefault(name, []).append((start, end))
        words = [ass_text(w[2].upper() if st['upper'] else w[2]) for w in clean]
        # Holding the current word until the next starts avoids flicker in short pauses.
        for index, (a, _, _) in enumerate(clean):
            b = clean[index + 1][0] if index + 1 < len(clean) else end
            text = words.copy()
            text[index] = r'{\1c' + color_ass(st['accent']) + '}' + text[index] + r'{\1c&HFFFFFF&}'
            tag = r'{\pos(540,' + str(y) + ')'
            if index == 0 and st['effect'] == 'pop':
                tag += r'\fscx89\fscy89\t(0,115,\fscx100\fscy100)'
            event(a, b, 'Main', tag + '}' + ' '.join(text))
    (directory / 'caption.ass').write_text('\n'.join(lines) + '\n', encoding='utf-8-sig')
    (directory / 'captions.srt').write_text('\n'.join(srt) + ('\n' if srt else ''), encoding='utf-8')
    return emojis


def framing(mode, pan, source):
    if mode == 'blur':
        return (f'{source}split[bg][fg];'
                '[bg]scale=270:480:force_original_aspect_ratio=increase,crop=270:480,boxblur=14:4,'
                'scale=1080:1920,setsar=1[background];'
                '[fg]scale=1080:1920:force_original_aspect_ratio=decrease:force_divisible_by=2,setsar=1[foreground];'
                '[background][foreground]overlay=(W-w)/2:(H-h)/2:shortest=1,setsar=1')
    balance = round(pan / 100, 3)
    return (f'{source}scale=1080:1920:force_original_aspect_ratio=increase,'
            f'crop=1080:1920:(iw-ow)*{balance}:(ih-oh)/2,setsar=1')


def make_cover(path, meta, opts, output):
    # Decode the chosen frame using the same framing used by the exported clip.
    with tempfile.TemporaryDirectory() as working:
        jpg = Path(working) / 'frame.jpg'
        time = min(max(0, meta['duration'] - .15), opts['frame'])
        ff(['-filter_complex_threads', '2', '-ss', f'{time:.3f}', *ff_input(path),
            '-filter_complex', framing(opts['framing'], opts['pan'], f'[0:{meta["video"]}]') + '[cover]',
            '-map', '[cover]', '-frames:v', '1', '-q:v', '2', str(jpg)])
        base = Image.open(jpg).convert('RGB')
    theme = opts['theme']
    accent = STYLES[opts['style']]['accent']
    cover = opts['cover'].strip()
    if not cover:
        base.save(output, quality=93, optimize=True)
        return
    base = ImageOps.autocontrast(base, cutoff=1)
    size = 110
    font_path = str(ASSETS / 'Caption-Bold.ttf')
    while True:
        font = ImageFont.truetype(font_path, size)
        rows = wrap(cover.upper() if theme != 'editorial' else cover, font, 860)
        if len(rows) <= 4 or size <= 50:
            break
        size -= 6
    spacing = round(size * 1.06)
    y = int(1470 - len(rows) * spacing / 2)
    overlay = Image.new('RGBA', base.size, (0, 0, 0, 0))
    pen = ImageDraw.Draw(overlay)
    if theme == 'poster':
        for row in range(max(0, y - 210), HEIGHT):
            alpha = min(225, round((row - (y - 210)) / 2))
            pen.line((0, row, WIDTH, row), fill=(10, 13, 20, alpha))
        pen.rounded_rectangle((100, y - 48, 246, y - 33), 7, accent)
    elif theme == 'editorial':
        pen.rounded_rectangle((64, y - 50, 1016, y + len(rows) * spacing + 40), 37, (13, 16, 24, 219))
        pen.rounded_rectangle((92, y - 19, 103, y + len(rows) * spacing + 11), 5, accent)
    base = Image.alpha_composite(base.convert('RGBA'), overlay)
    draw = ImageDraw.Draw(base)
    for i, row in enumerate(rows):
        draw.text((540, y + i * spacing), row, font=font, anchor='mt',
                  fill=accent if (theme != 'editorial' and i == len(rows) - 1) else 'white',
                  stroke_width=8 if theme == 'impact' else 2, stroke_fill='#151721')
    base.convert('RGB').save(output, quality=93, optimize=True)


def export(path, meta, opts, groups, directory, report):
    report('Composing styled captions, SRT, and cover')
    opts = dict(opts, font='Arial' if os.name == 'nt' and any(ord(c) > 0x2FF for g in groups for w in g for c in w[2])
                else 'Liberation Sans')
    emojis = captions(groups, opts, directory)
    shutil.copy(ASSETS / 'Caption-Bold.ttf', directory / 'Caption-Bold.ttf')
    for name in emojis:
        shutil.copy(ASSETS / f'{name}.png', directory / f'{name}.png')
    make_cover(path, meta, opts, directory / 'cover.jpg')
    graph = framing(opts['framing'], opts['pan'], f'[0:{meta["video"]}]')
    graph += ",fps=30,ass=caption.ass:fontsdir=.[captioned]"
    args = ['-filter_complex_threads', '2', '-ss', f'{opts["start"]:.3f}', *ff_input(path)]
    previous = 'captioned'
    position = round(HEIGHT * opts['caption_y'] / 100 - 183)
    for i, (name, intervals) in enumerate(emojis.items(), 1):
        args += ['-i', f'{name}.png']
        rule = '+'.join(f'between(t,{a:.3f},{b:.3f})' for a, b in intervals)
        graph += (f';[{i}:v]scale=106:106[emoji{i}];'
                  f"[{previous}][emoji{i}]overlay=(W-w)/2:{position}:enable='{rule}'[with{i}]")
        previous = f'with{i}'
    graph += f';[{previous}]format=yuv420p[out]'
    (directory / 'filters.txt').write_text(graph, encoding='ascii')
    args += ['-filter_complex_script', 'filters.txt', '-map', '[out]', '-map', '0:a:0?',
             '-t', f'{opts["end"] - opts["start"]:.3f}', '-c:a', 'aac', '-b:a', '160k',
             '-movflags', '+faststart']
    choices = []
    if opts['device'] != 'cpu':
        available = run([FFMPEG, '-hide_banner', '-encoders']).decode('utf-8', errors='replace')
        for codec, label, settings in [
            ('h264_nvenc', 'NVIDIA NVENC', ['-preset', 'p4', '-cq', '22']),
            ('h264_amf', 'AMD AMF', ['-quality', 'balanced']),
            ('h264_qsv', 'Intel Quick Sync', ['-global_quality', '23']),
        ]:
            if codec in available:
                choices.append((codec, label, settings))
    choices.append(('libx264', 'CPU / H.264', ['-preset', 'veryfast', '-crf', '21', '-threads', '4']))
    for codec, label, settings in choices:
        report(f'Rendering 1080 × 1920 video · {label}')
        try:
            ff([*args, '-c:v', codec, *settings, 'clip.mp4'], directory)
            return label
        except RuntimeError:
            if codec == 'libx264':
                raise
    raise RuntimeError('Video encoding failed.')
