# ClipForge Studio

ClipForge finds short-form candidates in a local video, generates word-timed captions, and exports vertical MP4s with editable opening text and JPG covers. There are no subscriptions, API keys, per-clip charges, or video uploads. Setup and the first use of each Whisper model require internet access. After the model is cached, the application can work offline.

## Start on Windows 10 or 11

1. Extract the **whole ZIP** to a writable folder such as **Documents**.
2. If needed, open **PowerShell** and install the following free dependencies. Close PowerShell when they finish.

   ```powershell
   winget install -e --id Python.Python.3.12
   winget install -e --id Gyan.FFmpeg
   ```

3. Open the extracted **ClipForge** folder and double-click **Start_ClipForge.cmd**. It creates a virtual environment and installs the Python packages on the first launch.
4. Keep that window open. The editor opens in your regular browser at **http://127.0.0.1:8765**. Only your computer can reach it.

Without WinGet, install [64-bit Python 3.12](https://www.python.org/downloads/release/python-31210/) and a full [Windows FFmpeg build](https://ffmpeg.org/download.html#build-windows). Put its **ffmpeg.exe** and **ffprobe.exe** in a folder named **bin** inside ClipForge, or add them to your PATH. Use an FFmpeg build with the **ass** filter and **libx264** encoder.

## Make your first clip

1. Choose a long local video. The app copies it to its local workspace and leaves the original in place.
2. Set **Target length** and **Max clips**, keep **Auto subtitles** enabled, and click **Analyze video**. Use **Tiny** if you want the first test to finish faster. **Base** is the default. **Small** and **Medium** give you other speed/accuracy tradeoffs. Set a language if detection struggles.
3. Click a suggested clip and scrub or play the preview. The ranking uses opening questions, surprise or setup phrases, speech boundaries, audio peaks, and visual activity. The score is a ranking heuristic. Short sources and heavily overlapping moments can produce fewer clips than the selected maximum.
4. Choose one of six **Caption presets** and move the captions up or down. Styles include Reaction Pop, Golden Karaoke, Purple Bubble, Red Impact, Clean Creator, and White Minimal. Auto emoji reacts to selected English cues such as “no way,” “funny,” and “watch this.”
5. Open **Hook & trim** to change the opening text, start and end times, and framing. The opening text appears for the first 2.65 seconds. If no spoken opening is available, add a short line that matches the clip. Use **Fill** for a tight crop or **Fit** to show the full frame over a blurred background. The **Horizontal crop position** slider adjusts the crop manually.
6. In **Cover**, type a short cover title. Pick **Gradient Poster**, **Bold Outline**, or **Dark Title Card**. **Use playhead** grabs the current frame time. **Preview cover** shows the actual JPG composition.
7. Click **Export clip**, or check **Export all suggested clips** to render them one by one. Each export folder contains an **MP4** at 1080 × 1920, a **JPG** cover, and a styled **ASS** file. Exports with recognized speech also include plain, editable **SRT**. Styling and emoji are burned into the MP4. The cover is a separate JPG.

You can download the results from the editor or find them under **ClipForge/workspace/exports**. Imported video copies and analysis data are under **ClipForge/workspace/projects**. Leave the browser tab open to keep the current editing session. To reclaim disk space, close ClipForge and remove unwanted folders from **workspace**.

## GPU and offline use

- **Whisper transcription** can use a compatible NVIDIA GPU with current drivers, CUDA 12 cuBLAS, and cuDNN 9 present on PATH. The [Faster-Whisper GPU installation guide](https://github.com/SYSTRAN/faster-whisper#gpu) has setup options. If the model needs more memory, try **Tiny**, **Base**, or **CPU**.
- **Video encoding** tries NVIDIA NVENC, AMD AMF, and Intel Quick Sync when available in FFmpeg, then falls back to CPU H.264. The editor displays the encoder used. Frame analysis and subtitle compositing run on CPU.
- **AMD and Intel GPUs** can accelerate encoding with a supported driver and FFmpeg build. Speech recognition uses CPU on those systems.
- To force offline mode after downloading a model, set the environment variable `HF_HUB_OFFLINE=1` before launching. Advanced users can point `CLIPFORGE_MODEL_PATH` to a local Faster-Whisper/CTranslate2 model directory.

On Linux with Python 3.12 and a full FFmpeg install, run `python3 -m venv .venv`, `.venv/bin/python -m pip install -r requirements.txt`, then `.venv/bin/python app.py`. If port 8765 is occupied, start with `app.py --port 8766` using the same Python executable.

## Editing expectations

ClipForge ranks signals from the footage and uses source dialogue when it suggests an opening. Review cuts and captions before publishing, especially when music or overlapping voices make speech difficult to recognize. The preview uses your browser's video decoder; if a source format cannot play there, FFmpeg can still analyze and export it. Complex movement may need a manual crop adjustment or blurred fit.
