@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    where py >nul 2>nul
    if errorlevel 1 (
        where python >nul 2>nul
        if errorlevel 1 goto missing_python
        python -m venv .venv
    ) else (
        py -3.12 -m venv .venv
    )
    if errorlevel 1 goto missing_python
)

if not exist ".venv\installed-v1.txt" (
    echo Installing local ClipForge dependencies. First run only.
    ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
    if errorlevel 1 goto install_failed
    echo ClipForge v1 > ".venv\installed-v1.txt"
)

rem Reload ffmpeg's WinGet link folder into this process after installation.
if exist "%LOCALAPPDATA%\Microsoft\WinGet\Links\ffmpeg.exe" set "PATH=%LOCALAPPDATA%\Microsoft\WinGet\Links;%PATH%"
where ffmpeg >nul 2>nul
if errorlevel 1 if not exist "bin\ffmpeg.exe" goto missing_ffmpeg
where ffprobe >nul 2>nul
if errorlevel 1 if not exist "bin\ffprobe.exe" goto missing_ffmpeg

".venv\Scripts\python.exe" app.py
if errorlevel 1 pause
exit /b

:missing_python
echo Install 64-bit Python 3.12, then run this file again.
echo Windows command: winget install -e --id Python.Python.3.12
goto finish

:missing_ffmpeg
echo Install FFmpeg, then close this window and run this file again.
echo Windows command: winget install -e --id Gyan.FFmpeg
echo You can also put ffmpeg.exe and ffprobe.exe in ClipForge\bin.
goto finish

:install_failed
echo Setup stopped while installing dependencies. Check the error above and run this file again.
:finish
pause
exit /b 1
