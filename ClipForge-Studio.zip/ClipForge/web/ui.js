'use strict';
const $ = (id) => document.getElementById(id);
const video = $('video');
const background = $('bgVideo');
const ui = {
  token: '', project: null, clips: [], groups: [], clip: null, styles: {}, style: 'reaction',
  busy: false, preview: 'video', lastGroup: null, lastWords: '', edits: new Map(),
};
const timeText = (s) => {
  const seconds = Math.max(0, Math.floor(Number(s) || 0));
  return Math.floor(seconds / 60) + ':' + String(seconds % 60).padStart(2, '0');
};
const rangeText = (a, b) => timeText(a) + ' – ' + timeText(b);
const rules = {
  laugh: /\b(laugh\w*|hilarious|funny|lmao|joke)\b/i,
  shock: /\b(no way|oh my god|what the|impossible|shocked|unbelievable|crazy)\b/i,
  fire: /\b(fire|insane|incredible|amazing|perfect|wild|strong)\b/i,
  skull: /\b(dead|rip|i'm done|i am done|destroyed|cooked)\b/i,
  idea: /\b(secret|tip|trick|learned|realized|mistake)\b/i,
  eyes: /\b(look at|look here|watch this|did you see|wait for it)\b/i,
};

function status(message, state = '') {
  $('status').dataset.state = state;
  $('status').querySelector('span').textContent = message;
}
function notice(message) {
  $('note').hidden = !message;
  $('note').textContent = message || '';
}
function buttons() {
  const ready = Boolean(ui.project);
  const clip = Boolean(ui.clip);
  $('file').disabled = ui.busy || !ui.token;
  $('analyze').disabled = !ready || ui.busy;
  $('export').disabled = !clip || ui.busy;
  $('showCover').disabled = !clip || ui.busy;
  $('useFrame').disabled = !clip || !Number.isFinite(video.duration) || ui.busy;
  $('play').disabled = !clip || !Number.isFinite(video.duration);
  $('seek').disabled = !clip || !Number.isFinite(video.duration);
  $('all').disabled = ui.busy || ui.clips.length < 2;
  $('export').firstChild.nodeValue = $('all').checked && !$('all').disabled ? 'Export all clips ' : 'Export clip ';
  $('clips').querySelectorAll('button').forEach((item) => {item.disabled = ui.busy;});
}
function options() {
  return {
    project: ui.project.id, style: ui.style, hook: $('hookText').value, cover: $('coverText').value,
    start: Number($('start').value), end: Number($('end').value), frame: Number($('frame').value),
    caption_y: Number($('captionY').value), emoji: $('emoji').checked, theme: $('theme').value,
    framing: $('framing').value, pan: Number($('pan').value), device: $('device').value,
  };
}
function clipDefaults(clip) {
  return { start: clip.start, end: clip.end, frame: clip.frame, hook: clip.hook, cover: clip.hook };
}
function edits(opts) {
  const {start, end, frame, hook, cover} = opts;
  return {start, end, frame, hook, cover};
}
async function api(path, data, file = false) {
  const headers = {'X-ClipForge-Token':ui.token};
  if (file) headers['X-File-Name'] = encodeURIComponent(data.name);
  else headers['Content-Type'] = 'application/json';
  const res = await fetch(path, {method:'POST', headers, body:file ? data : JSON.stringify(data)});
  const body = await res.json();
  if (!res.ok) throw new Error(body.error || 'Action failed.');
  return body;
}
async function job(path, data, prefix = '') {
  const queued = await api(path, data);
  for (;;) {
    const res = await fetch('/api/job/' + queued.job, {cache:'no-store'});
    const reply = await res.json();
    if (!res.ok || reply.state === 'error') throw new Error(reply.error || reply.message || 'Local job failed.');
    if (reply.state === 'done') return reply.result;
    status(prefix + reply.message, 'busy');
    await new Promise((done) => setTimeout(done, 650));
  }
}
async function perform(action) {
  if (ui.busy) return;
  ui.busy = true;
  buttons();
  try { await action(); }
  catch (error) { status(error.message, 'error'); }
  finally {
    ui.busy = false;
    buttons();
  }
}

function setPreview(mode) {
  ui.preview = mode;
  $('coverImage').hidden = mode !== 'cover';
  $('showCover').textContent = mode === 'cover' ? 'Back to clip' : 'Preview cover';
  paintOverlay(true);
}
function markCandidates() {
  $('clips').querySelectorAll('button').forEach((button) => {
    button.setAttribute('aria-pressed', String(Number(button.dataset.id) === ui.clip?.id));
  });
}
function selectClip(clip) {
  if (ui.clip && ui.project) ui.edits.set(ui.clip.id, edits(options()));
  ui.clip = clip;
  const values = ui.edits.get(clip.id) || clipDefaults(clip);
  $('hookText').value = values.hook;
  $('coverText').value = values.cover;
  $('start').value = values.start;
  $('end').value = values.end;
  $('frame').value = values.frame;
  $('seek').min = values.start;
  $('seek').max = values.end;
  $('seek').value = values.start;
  video.pause();
  if (Number.isFinite(video.duration)) seek(values.start);
  setPreview('video');
  markCandidates();
  buttons();
}
function renderCandidates() {
  $('clips').replaceChildren();
  $('clipCount').textContent = ui.clips.length ? String(ui.clips.length) : '';
  for (const clip of ui.clips) {
    const card = document.createElement('button');
    card.className = 'candidate';
    card.dataset.id = clip.id;
    card.title = clip.reason.join(' · ') + ' · Hook score ' + clip.score + '/100';
    const image = document.createElement('img');
    image.alt = '';
    image.src = '/thumb/' + ui.project.id + '/' + clip.id;
    const info = document.createElement('div');
    const title = document.createElement('strong');
    title.textContent = clip.hook || 'Suggested moment ' + clip.id;
    const detail = document.createElement('small');
    detail.textContent = rangeText(clip.start, clip.end) + ' · ' + clip.reason[0];
    info.append(title, detail);
    const score = document.createElement('span');
    score.className = 'score';
    score.textContent = clip.score;
    score.setAttribute('aria-label', 'Hook score ' + clip.score + ' out of 100');
    card.append(image, info, score);
    card.addEventListener('click', () => selectClip(clip));
    $('clips').append(card);
  }
  if (!ui.clips.length) {
    const empty = document.createElement('p');
    empty.className = 'hint';
    empty.textContent = 'Your ranked clips will appear here.';
    $('clips').append(empty);
  }
  markCandidates();
}

async function importVideo(file) {
  if (!file) return;
  await perform(async () => {
    status('Copying the video into the local workspace…', 'busy');
    const project = await api('/api/import', file, true);
    ui.project = project;
    ui.clips = [];
    ui.groups = [];
    ui.clip = null;
    ui.edits.clear();
    notice('');
    renderCandidates();
    $('downloads').replaceChildren();
    $('dropTitle').textContent = project.meta.name;
    $('dropTitle').title = project.meta.name;
    const m = project.meta;
    $('dropInfo').textContent = timeText(m.duration) + ' · ' + m.width + ' × ' + m.height;
    $('empty').hidden = true;
    $('previewHint').textContent = '';
    const src = '/source/' + project.id;
    video.src = src;
    background.removeAttribute('src');
    for (const id of ['start','end','frame']) $(id).max = m.duration;
    selectClip({id:0, start:0, end:m.duration, frame:Math.min(1, m.duration), hook:''});
    syncFrame();
    status('Ready. Analyze the video to find hooks and generate word-timed captions.');
  });
}

function seek(t) {
  if (Number.isFinite(video.duration)) {
    const pos = Math.max(0, Math.min(video.duration, t));
    video.currentTime = pos;
    if (Number.isFinite(background.duration)) background.currentTime = pos;
  }
  paintOverlay(true);
}
function syncFrame() {
  const blur = $('framing').value === 'blur';
  $('phone').classList.toggle('blur', blur);
  $('phone').style.setProperty('--pan', $('pan').value + '%');
  $('pan').disabled = blur;
  if (blur && ui.project) {
    const src = '/source/' + ui.project.id;
    if (background.getAttribute('src') !== src) background.src = src;
    if (Number.isFinite(background.duration) && Math.abs(background.currentTime - video.currentTime) > .12) {
      background.currentTime = video.currentTime;
    }
    if (!video.paused) background.play().catch(() => {});
  } else background.pause();
}
function groupAt(time) {
  let low = 0, high = ui.groups.length;
  while (low < high) {
    const middle = Math.floor((low + high) / 2);
    if (ui.groups[middle][0][0] <= time) low = middle + 1;
    else high = middle;
  }
  const group = ui.groups[low - 1];
  return group && time < group.at(-1)[1] ? group : null;
}
function paintOverlay(force = false) {
  const caption = $('captionPreview');
  const hook = $('hookPreview');
  const emoji = $('emojiPreview');
  if (!ui.clip || ui.preview === 'cover') {
    caption.hidden = hook.hidden = emoji.hidden = true;
    return;
  }
  const t = video.currentTime || 0;
  const start = Number($('start').value);
  const end = Number($('end').value);
  const len = Math.max(0, end - start);
  const offset = Math.max(0, Math.min(len, t - start));
  $('seek').value = t;
  $('clock').textContent = timeText(offset) + ' / ' + timeText(len);
  hook.textContent = $('hookText').value.trim();
  hook.hidden = !hook.textContent || t < start || t >= Math.min(end, start + 2.65);
  const group = groupAt(t);
  const st = ui.styles[ui.style];
  if (!group || !st || t >= end || t < start) {
    caption.hidden = emoji.hidden = true;
    ui.lastGroup = null;
    return;
  }
  const active = group.findLastIndex((w) => w[0] <= t);
  const wordKey = ui.style + ':' + active;
  if (force || group !== ui.lastGroup || wordKey !== ui.lastWords) {
    caption.replaceChildren();
    group.forEach((w, index) => {
      if (index) caption.append(' ');
      const span = document.createElement('span');
      span.textContent = st.upper ? w[2].toUpperCase() : w[2];
      if (index === active) span.style.color = st.accent;
      caption.append(span);
    });
    caption.classList.toggle('bubble', st.box);
    if (group !== ui.lastGroup) {
      caption.classList.remove('pop');
      void caption.offsetWidth;
      if (st.effect === 'pop') caption.classList.add('pop');
    }
    ui.lastGroup = group;
    ui.lastWords = wordKey;
  }
  const y = Number($('captionY').value);
  caption.style.setProperty('--position', y + '%');
  caption.style.setProperty('--font-size', (st.size / 10.8) + 'cqw');
  caption.style.setProperty('--outline', (st.stroke * .155) + 'cqw');
  caption.hidden = false;
  const text = group.map((word) => word[2]).join(' ');
  const name = $('emoji').checked && Object.keys(rules).find((key) => rules[key].test(text));
  emoji.hidden = !name;
  if (name) {
    const src = '/assets/' + name + '.png';
    if (emoji.getAttribute('src') !== src) emoji.src = src;
    emoji.style.setProperty('--emoji-position', (y - 9.5) + '%');
  }
}

function renderStyles() {
  $('styles').replaceChildren();
  Object.entries(ui.styles).forEach(([key, st]) => {
    const button = document.createElement('button');
    button.className = 'preset';
    button.setAttribute('aria-pressed', String(ui.style === key));
    const sample = document.createElement('strong');
    sample.textContent = st.upper ? st.sample.toUpperCase() : st.sample;
    sample.style.color = st.accent;
    const name = document.createElement('small');
    name.textContent = st.name;
    button.append(sample, name);
    button.addEventListener('click', () => {
      ui.style = key;
      for (const item of $('styles').children) item.setAttribute('aria-pressed', String(item === button));
      paintOverlay(true);
    });
    $('styles').append(button);
  });
}

function addDownload(result, number) {
  const pane = document.createElement('div');
  pane.className = 'download';
  const title = document.createElement('strong');
  title.textContent = number ? 'Clip ' + number + ' · ' + result.encoder : 'Exported · ' + result.encoder;
  pane.append(title);
  for (const [key, label, filename] of [
    ['video','MP4','clip.mp4'], ['cover','Cover JPG','cover.jpg'],
    ['srt','SRT','captions.srt'], ['ass','Styled ASS','caption.ass'],
  ]) {
    if (!result[key]) continue;
    const link = document.createElement('a');
    link.href = result[key];
    link.download = filename;
    link.textContent = label;
    pane.append(link);
  }
  $('downloads').append(pane);
}
function currentFrame() {
  const start = Number($('start').value);
  const end = Number($('end').value);
  return Math.min(end, Math.max(start, Number($('frame').value)));
}

$('file').addEventListener('change', () => {
  const file = $('file').files[0];
  $('file').value = '';
  importVideo(file);
});
for (const event of ['dragover','dragleave','drop']) {
  $('drop').addEventListener(event, (e) => {
    e.preventDefault();
    $('drop').classList.toggle('drag', event === 'dragover');
    if (event === 'drop' && ui.token) importVideo(e.dataTransfer.files[0]);
  });
}
$('analyze').addEventListener('click', () => perform(async () => {
  video.pause();
  status('Starting local analysis…', 'busy');
  notice('');
  const result = await job('/api/analyze', {
    project:ui.project.id, model:$('model').value, device:$('device').value, language:$('language').value,
    length:Number($('length').value), count:Number($('count').value), speech:$('speech').checked,
  });
  ui.clips = result.clips;
  ui.groups = result.groups;
  ui.edits.clear();
  ui.clip = null;
  $('all').checked = false;
  renderCandidates();
  if (ui.clips.length) selectClip(ui.clips[0]);
  notice(result.note);
  status(result.clips.length + ' suggested ' + (result.clips.length === 1 ? 'clip' : 'clips')
    + ' · ' + result.device + (result.language ? ' · Speech language: ' + result.language : ''));
}));
$('export').addEventListener('click', () => perform(async () => {
  if (!ui.clip) return;
  video.pause();
  const base = options();
  base.frame = currentFrame();
  ui.edits.set(ui.clip.id, edits(base));
  const batch = $('all').checked && ui.clips.length > 1 ? ui.clips : [ui.clip];
  $('downloads').replaceChildren();
  for (let i = 0; i < batch.length; i++) {
    const clip = batch[i];
    const progress = batch.length > 1 ? (i + 1) + '/' + batch.length + ' · ' : '';
    status(progress + 'Preparing export…', 'busy');
    const request = {...base, ...(ui.edits.get(clip.id) || clipDefaults(clip))};
    const result = await job('/api/export', request, progress);
    addDownload(result, batch.length > 1 ? clip.id : null);
  }
  status(batch.length === 1 ? 'Clip exported. Download it from the editor or open the workspace/exports folder.'
    : batch.length + ' clips exported. Find them in the editor or workspace/exports.');
}));
$('showCover').addEventListener('click', () => {
  if (ui.preview === 'cover') return setPreview('video');
  perform(async () => {
    video.pause();
    status('Preparing the cover…', 'busy');
    const result = await job('/api/cover', {...options(), frame:currentFrame()});
    $('coverImage').src = result.cover;
    setPreview('cover');
    status('Cover preview ready. Export the clip to save the JPG.');
  });
});
$('useFrame').addEventListener('click', () => {
  $('frame').value = Math.max(Number($('start').value), Math.min(Number($('end').value), video.currentTime)).toFixed(3);
  if (ui.preview === 'cover') setPreview('video');
});
for (const tab of document.querySelectorAll('.tabs button')) {
  tab.addEventListener('click', () => {
    for (const other of document.querySelectorAll('.tabs button')) {
      other.setAttribute('aria-pressed', String(tab === other));
      $(other.dataset.tab).hidden = tab !== other;
    }
    if (tab.dataset.tab !== 'cover') setPreview('video');
  });
}
$('all').addEventListener('change', buttons);
$('play').addEventListener('click', async () => {
  setPreview('video');
  if (!video.paused) return video.pause();
  const start = Number($('start').value), end = Number($('end').value);
  if (video.currentTime < start || video.currentTime >= end - .004) seek(start);
  try { await video.play(); syncFrame(); }
  catch (err) { status(err.message, 'error'); }
});
$('seek').addEventListener('input', () => {
  setPreview('video');
  seek(Number($('seek').value));
});
for (const id of ['start','end']) {
  $(id).addEventListener('change', () => {
    const start = Number($('start').value);
    const end = Number($('end').value);
    if (end <= start) return;
    $('seek').min = start;
    $('seek').max = end;
    $('frame').value = currentFrame();
    video.pause();
    seek(start);
  });
}
for (const id of ['hookText','captionY','emoji']) $(id).addEventListener('input', () => paintOverlay(true));
for (const id of ['framing','pan']) $(id).addEventListener('input', syncFrame);
video.addEventListener('loadedmetadata', () => {
  seek(Number($('start').value));
  buttons();
});
video.addEventListener('error', () => {
  $('previewHint').textContent = 'This source format cannot play in your browser. You can still analyze it and export a playable MP4.';
  buttons();
});
video.addEventListener('play', () => {
  $('play').textContent = '❚❚';
  $('play').setAttribute('aria-label', 'Pause clip');
});
video.addEventListener('pause', () => {
  background.pause();
  $('play').textContent = '▶︎';
  $('play').setAttribute('aria-label', 'Play clip');
});
video.addEventListener('timeupdate', () => {
  const end = Number($('end').value);
  if (ui.clip && !video.paused && video.currentTime >= end) {
    video.pause();
    seek(end);
  }
  paintOverlay();
});
if (video.requestVideoFrameCallback) {
  function drawFrame() {
    paintOverlay();
    video.requestVideoFrameCallback(drawFrame);
  }
  video.requestVideoFrameCallback(drawFrame);
}
fetch('/api/config')
  .then((res) => res.json())
  .then((config) => {Object.assign(ui, config); renderStyles(); buttons();})
  .catch((error) => status('Could not connect to the local app. ' + error.message, 'error'));
